import { Component } from '@angular/core';
import{CategoriasService} from '../../services/categorias.service'
@Component({
  selector: 'app-categorias',
  templateUrl: './categorias.component.html',
  styleUrls: ['./categorias.component.css']
})
export class CategoriasComponent {
categorias : any
constructor(private categoriasService: CategoriasService){
  this.categoriasService.list().subscribe((resCategorias: any) => {
    console.log(resCategorias);
    this.categorias=resCategorias
},
    (err: any) => console.error(err)
  );
}
eliminarCategoria(id:any){
  console.log("eliminar categoria "+id)
  this.categoriasService.eliminar(id).subscribe((resCategorias: any) => {
    console.log(resCategorias);
    this.categoriasService.list().subscribe((resCategorias: any) => {
      console.log(resCategorias);
      this.categorias=resCategorias
  },
      (err: any) => console.error(err)
    );
},
    (err: any) => console.error(err)
  );
}
visualizarCategoria(id:any){
  console.log("visualizar categoria "+id)

}
editarCategoria(id:any){
  console.log("editar categoria "+id)

}
}
