import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {CategoriasService} from './../../services/categorias.service'
import { Cliente } from '../../models/cliente';
import {ClientesService} from '../../services/clientes.service'
import { MembresiaService } from '../../services/membresia.service';
//import * as $ from 'jquery';
declare var $ : any;


@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit{
  clientes : any
  cliente = new Cliente();
  tipoUsuario:number
  categorias:any;
  membresias: any;


  constructor(private router: Router,
    private clientesService:ClientesService,
    private membresiaService: MembresiaService, 
    private categoriasService: CategoriasService) {
    
    this.tipoUsuario = Number(localStorage.getItem("tipoUsuario"))
    console.log(this.tipoUsuario)
    
    this.membresiaService.list().subscribe((resMembresias: any) => {
      console.log(resMembresias);
      this.membresias = resMembresias;
  },
      (err: any) => console.error(err)
    );
  }
  ngOnInit() {
    //var elems = document.querySelectorAll('.sidenav');
    //var instances = M.Sidenav.init(elems, {});
    $(document).ready(function ()
    {
      $(".modal").modal();

    })  
    
  }
  agregarCliente(){

    console.log(this.cliente);
    this.clientesService.insertar(this.cliente).subscribe((resClientes: any) => {
      console.log(resClientes);
  },
      (err: any) => console.error(err)
    );
  
  }
  visualizarFormularioCliente(){
    $('#modalClientes').modal();
    $('#modalClientes').modal("open");
  }
  salir(){
    localStorage.removeItem("tipoUsuario")
    this.router.navigate(['login'])
    console.log("salir")
  }
}
