export const environment = {
    production: false,
    //declariacion de la variable global, con el siguiente atributo:
    API_URI: "http://localhost:3000/api",
    API_URI_CORREOS: "http://localhost:3001",
};
    