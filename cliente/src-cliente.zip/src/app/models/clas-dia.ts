export class ClasDia{
    clase: string;
    dia:string;
    //carmagos el servicio directamente en este modelo de datos 
    constructor() {
        this.clase= "";
		this.dia="";
    }
}