export class NoteSave{
    id_cliente: number;
    nota: string;
    //carmagos el servicio directamente en este modelo de datos 
    constructor() {
        this.id_cliente= 0;
		this.nota= ""
    }
}